# Tourism-Management-System

This is a Tourism Management System Project build by using html, css, javascript, php, MySQL as mini project in the 5th semister of engineering.
This website has cool SignUp/SignIn page where you can enter your details and SignUp.
It stores your data in the database using php and MySQL queries.
This website has a cool front page where you can see many destinations, you can also get the data about each place.
There is also a galery section where you can see the beautifull pictures of all the destinations.
This website also has the admin login admin can get the information of the customers, travel agents, also can add new places, hotels.
There is cool and nice booking page where you can book your tour by entering your details.
This website also has a feedback section where you can give your feedback to the developer.

# New Changes

improved performance
login signup isssues fixed
styling issues fixed

# Use Procedure

please chanage the port number with your port number - I used 3307 as port number but for your case it may be 3306 please change that

please change username and password if that applicable to you

create database called "travel", don't give any other name,
if you want different name for database then make sure that you change database ame in code also

database file also provided

Thank You....
